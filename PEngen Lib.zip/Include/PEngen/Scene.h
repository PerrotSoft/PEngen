﻿#pragma once

#define GLM_ENABLE_EXPERIMENTAL
#include <map>
#include <string>
#include <mutex>
#include <thread>
#include <memory>
#include <vector>
#include <iostream>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/quaternion.hpp>

// Подключаем ВАШУ библиотеку
#include "../gnu/OpenGL.h"

using GLuint = unsigned int;
using namespace std;
using namespace gnu; // Пространство имен вашей библиотеки

namespace PEngen {

    // --- PESGameObject: Основная сущность ---
    struct PESGameObject {
        GLuint id = 0;
        string name;

        // Трансформация (Локальная)
        glm::vec3 position{ 0.0f };
        glm::quat rotation{ 1.0f, 0.0f, 0.0f, 0.0f };
        glm::vec3 scale{ 1.0f };
        glm::mat4 cached_transform = glm::mat4(1.0f);

        // Иерархия
        // Исправлено: не инициализировать std::string через nullptr — пустая строка означает "без родителя"
        string parent_name;
        uint8_t state = 0;// 0 - неактивен, 1 - 3D Model Base Color, 2 - Model Texture, 3 - UI Bututton, 4 - UI Checkbox, 5 - UI InputField, 6 - UI Panel, 7 - UI Image

        // --- КОМПОНЕНТЫ (Взяты из вашей библиотеки) ---
        // 3D
        PEGLModel model;
        // UI
        UI::PEGLButton button_ui;
        UI::PEGLCheckbox checkbox_ui;
        UI::PEGLInputField inputfield_ui;
        UI::PEGLPanel panel_ui;
        UI::PEGLImage image_ui;
        // Расчет локальной матрицы T*R*S
        glm::mat4 calculate_local_matrix() const;
    };

    // --- PESScene: Сцена ---
    struct PESScene {
        string scene_name;
        std::vector<PESGameObject*> Scene_objects;
        GLuint next_object_id = 1;
    };

    // --- Глобальный контекст ---
    struct EngineContext {
        PESScene* active_scene = nullptr;
        bool is_update_task_running = false;
        std::unique_ptr<std::thread> update_thread;
    };
    extern EngineContext GContext;

    // --- PESRenderer: Система рендеринга ---
    class PESRenderer {
    public:
        struct PESRObject {
            GLuint id = 0;

            // Трансформация (Локальная)
            glm::vec3 position{ 0.0f };
            glm::quat rotation{ 1.0f, 0.0f, 0.0f, 0.0f };
            glm::vec3 scale{ 1.0f };
            glm::mat4 cached_transform = glm::mat4(1.0f);
            uint8_t state = 0;// 0 - неактивен, 1 - 3D Model Base Color, 2 - Model Texture, 3 - UI Bututton, 4 - UI Checkbox, 5 - UI InputField, 6 - UI Panel, 7 - UI Image
            PEGLModel model;
            UI::PEGLButton button_ui;
            UI::PEGLCheckbox checkbox_ui;
            UI::PEGLInputField inputfield_ui;
            UI::PEGLPanel panel_ui;
            UI::PEGLImage image_ui;
        };
        // Предварительный рендер: расчет иерархии и отправка команд
        static vector<PESRenderer::PESRObject> render_pre();
        // Финализация (если нужна)
        static void render();
    };

    // --- API Функции ---
    // Инициализация сцены шейдерами
    void PESInit_Scene(PESScene& scene);

    // Добавление объекта (возвращает ссылку на созданный объект)
    PESGameObject& PESAddObject(PESGameObject& object_template);
    PESGameObject& PESSearchObject(const char* name);
    // Удаление объекта по ID
    void PESRemoveObject(const char* name);

} // namespace PEngen