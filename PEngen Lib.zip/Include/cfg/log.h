#pragma once
void logger(const char* message);	
void logger_up(const char* message);
